--*************************************************************************--
-- Title: Module03-Lab03
-- Author: YourNameHere
-- Desc: This file demonstrates how to select data from a database
-- Change Log: When,Who,What
-- 2017-01-01,YourNameHere,Created File
--**************************************************************************--
Use Northwind;
go

-- Question 3-1:  Select the category name and product name all products in the Northwind database. 